<?php 
require_once('database/config.php');
?>
<?php include('include/header.php');?>

<div class="card">
  <div class="card-body">
  <h5 class="text-center text-dark">All Collection In the Fasion House.</h4> </h5>

  </div>
</div>

<section class="on-sale">
<div class="container">
    <div class="title-box">
    <h2> Collections</h2>
    </div>
    <div class="row">
    <?php storePage() ?>
    </div>
</div>  
</section>


<?php include('include/web_feature.php');?>
<!------------Footer----------->
<?php include('include/footer.php');?>