<div class="slider">
  <div id="slider" class="carousel slide carousel-fade" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="images/img-1.png" class="d-block w-100">
    </div>
    
    <div class="carousel-item">
      <img src="images/img-2.jpg" class="d-block w-100">
    </div>

    <div class="carousel-item">
      <img src="images/img-3.jpg" class="d-block w-100">
    </div>

    <div class="carousel-item">
      <img src="images/img-4.jpg" class="d-block w-100">
    </div>

    <div class="carousel-item">
      <img src="images/img-5.jpg" class="d-block w-100">
    </div>
   
      <div class="carousel-item">
      <img src="images/img-6.jpg" class="d-block w-100">
    </div>


  </div>
  <ol class="carousel-indicators">
    <li data-target="#slider" data-slide-to="0" class="active"></li>
    <li data-target="#slider" data-slide-to="1"></li>
    <li data-target="#slider" data-slide-to="2"></li>
    <li data-target="#slider" data-slide-to="3"></li>
    <li data-target="#slider" data-slide-to="4"></li>
    <li data-target="#slider" data-slide-to="5"></li>
    
    
  </ol>
</div>  
</div>    



</section>