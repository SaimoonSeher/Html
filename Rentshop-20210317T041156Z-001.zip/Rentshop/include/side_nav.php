<section class="header">
<div class="side-menu" id="side-menu">
<ul>
<li>My Account <i class="fa fa-angle-right"></i>
            <ul>
            <li>
            <a href="my-account.php">My Orders</a>
            </li>
            <li>
            <a href="logout.php">Logout</a>
            </li>
            </ul>
</li>

<li>Fashion Houses<i class="fa fa-angle-right"></i>
            <ul>
            
        
            <?php store()?>

            
            </ul>
</li>
<?php
get_categories();
?>

</ul>  
</div>