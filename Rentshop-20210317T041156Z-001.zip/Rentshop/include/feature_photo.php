
<section class="featured-categories"> 
<div class="container">
 <div class="row">
     <div class="col-md-4">
     <img src="images/categories1.jpg">
    </div>
     <div class="col-md-4">
     <img src="images/categories2.jpeg">
    </div>
     <div class="col-md-4">
     <img src="images/categories3.jpg">
    </div>
</div>   
</div>   
</section>