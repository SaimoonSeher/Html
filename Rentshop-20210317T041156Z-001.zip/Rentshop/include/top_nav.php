<div class="top-nav-bar">
<div class="search-box">
    <i class="fa fa-bars" id="menu-btn" onclick="openmenu()"></i>
    <i class="fa fa-times" id="close-btn" onclick="closemenu()"></i>
    
<a href="index.php" ><img src="images/logo.png" width="110px" height="40px" class="logo"> </a>

</div> 
<div class="menu-bar">
<ul>
<li><a href="shop.php">Products</a></li> 
<li><a href="aboutus.php">About US</a></li>
 
<li><a href="contact.php">Contact Us</a></li>     
<li><a href="cart.php"><i class="fa fa-shopping-basket"></i>cart</a></li>  
</ul>   
</div> 
</div>