
<section class="website-features">
<div class="container">
<div class="row">
<div class="col-md-3 feature-box">
<img src="images/feature-1.png"> 
<div class="feature-text">
<p><b>100% Original items </b>are available at company</p>    
</div>
</div>  
<div class="col-md-3 feature-box">
<img src="images/feature-2.png"> 
<div class="feature-text">
<p><b>Return within 30 days </b>of receiving your order.</p>    
</div>
</div> 
<div class="col-md-3 feature-box">
<img src="images/feature-3.png"> 
<div class="feature-text">
<p><b>Get free delivery for every</b>order on more than price.</p>    
</div>
</div>
<div class="col-md-3 feature-box">
<img src="images/feature-4.png"> 
<div class="feature-text">
<p><b>Pay Online through multiple </b>options (card/Net banking)</p>    
</div>
</div> 
</div>    
</div>    
</section>