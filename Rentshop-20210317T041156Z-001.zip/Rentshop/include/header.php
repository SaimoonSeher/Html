<html>
<head>
<title>E-Rent</title>
<link rel="stylesheet" href="css/style.css?<?php echo time() ?>">
<link rel="stylesheet" href="css/product.css?<?php echo time() ?>">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>
</head>
<body>

<?php include('top_nav.php');?>









