-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 16, 2021 at 11:24 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.4.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `erent`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `firstname`, `lastname`, `email`, `password`) VALUES
(1, 'saimon', 'seher', 'admin@gmail.com', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`) VALUES
(2, 'MEN'),
(3, 'WOMEN'),
(4, 'Foot Wear'),
(5, 'Watch'),
(6, 'Eye Glass'),
(7, 'Jewelry'),
(8, 'Purse & Bags');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `timestamp` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `email`, `subject`, `message`, `timestamp`) VALUES
(1, 'tyxi@mailinator.com', 'Anim velit eos accus', 'Eveniet voluptas no', '0000-00-00 00:00:00'),
(2, 'cyvyzoho@mailinator.com', 'Et maxime duis rerum', 'Dolorem tempor possi', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `orderitems`
--

CREATE TABLE `orderitems` (
  `id` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `rent_time` varchar(255) NOT NULL,
  `orderid` int(11) NOT NULL,
  `productprice` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orderitems`
--

INSERT INTO `orderitems` (`id`, `pid`, `rent_time`, `orderid`, `productprice`) VALUES
(1, 26, '1', 1, '250'),
(2, 25, '1', 2, '300'),
(3, 17, '1', 2, '200'),
(4, 28, '1', 3, '400'),
(5, 20, '1', 5, '1400'),
(6, 7, '1', 5, '300'),
(7, 39, '1', 5, '530'),
(8, 13, '1', 5, '1200'),
(9, 42, '1', 6, '300'),
(10, 21, '1', 6, '200'),
(11, 20, '1', 7, '1400'),
(12, 5, '1', 8, '1600');

-- --------------------------------------------------------

--
-- Table structure for table `ordertracking`
--

CREATE TABLE `ordertracking` (
  `id` int(11) NOT NULL,
  `status` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `timestamp` datetime NOT NULL,
  `orderid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ordertracking`
--

INSERT INTO `ordertracking` (`id`, `status`, `message`, `timestamp`, `orderid`) VALUES
(1, 'Delivered', ' thanks for your booking', '0000-00-00 00:00:00', 8),
(2, 'Delivered', ' thanks for your booking', '0000-00-00 00:00:00', 8),
(3, 'In Progress', ' ', '0000-00-00 00:00:00', 8),
(4, 'Delivered', ' ', '0000-00-00 00:00:00', 8),
(5, 'Dispatched', ' ', '0000-00-00 00:00:00', 5);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `catid` int(11) NOT NULL,
  `storeid` int(11) NOT NULL,
  `price` varchar(255) NOT NULL,
  `thumb` varchar(255) NOT NULL,
  `prod_desc` text NOT NULL,
  `short_desc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `catid`, `storeid`, `price`, `thumb`, `prod_desc`, `short_desc`) VALUES
(2, 'Pakistani Salwar', 3, 1, '200', 'uploads/salwar-1.jpg', 'If you love flaunting ethnic print kurtas, then this whole set is for you. It is a set of two, a straight kurta with trousers. Crafted with pure cotton and pastel colour makes it soft to touch and apt to wear in any season.\r\n Beige with orange and black print, potli buttons mock placket. Straight hem, knee length, Slit sides, 3/4th sleeves \r\nTrousers:Beige with ethnic print, Elasticated back slip-on style and 2 slash\r\n', ''),
(3, 'Embroidered Saree', 3, 4, '500', 'uploads/saree 1.jpg', 'lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero\'s De Finibus Bonorum et Malorum for use in a type specimen book.', 'lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero\'s De Finibus Bonorum et Malorum for use in a type specimen book.'),
(4, 'Pink Wedding Saree', 3, 5, '400', 'uploads/saree_1_300x350.jpg', 'Pink Wedding Saree has an embroidered border, \r\nThe model is wearing a blouse from our stylist\'s collection, see the image for a mock-up of what the actual blouse would look like\r\n', 'lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero\'s De Finibus Bonorum et Malorum for use in a type specimen book.'),
(5, 'Embroidered bridal lehenga', 3, 4, '1600', 'uploads/lehe_300x350.jpg', 'Maroon and beige zari embroidered semi-stitched lehenga and unstitched choli with dupatta\r\nMaroon zari embroidered unstitched choli fabric\r\nBeige zari embroidered semi-stitched lehenga, has an elasticated waistband, flared hem, an attached lining\r\nMaroon and gold-toned printed embellished dupatta with zari embroidered tapin\r\n', 'lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero\'s De Finibus Bonorum et Malorum for use in a type specimen book.'),
(6, 'Cotton Jacquard Salwar', 3, 3, '300', 'uploads/salwar.jpg', 'Gold-toned solid kurta with palazzos\r\nBurgundy A-line calf length kurta, has a round neck, three-quarter sleeves, printed border and flared hem\r\nGold-toned solid palazzos\r\nBurgundy and gold-toned printed Dupatta with zari border\r\n', 'lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero\'s De Finibus Bonorum et Malorum for use in a type specimen book.'),
(7, 'Salwar Suit ', 3, 5, '300', 'uploads/salwar1.jpg', 'Burgundy and gold-toned solid kurta with palazzos\r\n\r\n# Burgundy A-line calf length kurta, has a round neck, three-quarter sleeves, printed border and flared hem\r\n\r\n# Gold-toned solid palazzos\r\n\r\n# Burgundy and gold-toned printed Dupatta with zari border\r\n', 'lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero\'s De Finibus Bonorum et Malorum for use in a type specimen book.'),
(8, 'Velvet Saree', 3, 5, '700', 'uploads/saree-3.jpg', 'Velvet saree with a contrasting colour combination of blouse of velvet material is a total stunner; it looks so chic and classy when paired with right amount of elegant accessories. Cotton and silk blouse with deep neck designs on the blouse or any other designs of your own choice will look perfect for any occasion like weddings or engagements to attend.', 'lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero\'s De Finibus Bonorum et Malorum for use in a type specimen book.'),
(9, 'Silk Saree', 3, 2, '550', 'uploads/saree-4.jpg', 'Many Bangladeshi brides wear pure silk saris like red Banarasi silk saree for their wedding rituals. You will get a wide variety of Bridal, Wedding, and Designer Silk Saris on Saree.com. Gorgeous Silk Saree Blouses make these drapes all modern and stylish. At saree.com, you will get the latest designs and patterns in silk saree blouses.', 'lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero\'s De Finibus Bonorum et Malorum for use in a type specimen book.'),
(10, 'Versace Coat', 2, 5, '800', 'uploads/7c20e7d56058bf928a52295774898855.jpg', 'Statement outerwear is reflected in this voluminous puffer jacket in the golden Barocco Mosaic print - a mix of archive designs that celebrate brand heritage. The bold hooded jacket features an embroidered signature of Gianni Versace on reverse and accent Medusa buttons', 'lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero\'s De Finibus Bonorum et Malorum for use in a type specimen book.'),
(11, 'Gucci Gentle', 2, 10, '900', 'uploads/00341291_2.jpg', 'About Gucci Men\'s Coats and Jackets . Since 1921, the Gucci fashion line has produced some of the best-selling clothing and leather goods in the industry. With an emphasis on quality craftsmanship, Gucci jackets embody a sleek, sophisticated, and modern style in both casual and formal designs. Keep warm in style with a men\'s vintage leather jacket with a plush shearling lining.', 'lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero\'s De Finibus Bonorum et Malorum for use in a type specimen book.'),
(12, 'Custom Suit Set', 2, 9, '700', 'uploads/68e7e7f84ec6dce6704ef5f7288ccc27.jpg', 'At its most basic, a men’s suit is a jacket and trousers of the same cut, made from the same material, and intended to be worn together. Such a simple definition, however, denies much of the suit’s personality, and it is that personality that has made the suit a lasting and essential element of a gentleman’s outfitting.', 'lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero\'s De Finibus Bonorum et Malorum for use in a type specimen book.'),
(13, 'Gucci Tuxedo', 9, 10, '1200', 'uploads/6791b58aa8aaa5483edc4b00bb4086ff.jpg', 'A stretch twill tuxedo trimmed with red piping, inspired by the one worn by Jared Leto at the 2016 Oscars. Tailored in Gucci\'s Heritage fit with a slim jacket and slightly cropped pants. Black \'70s stretch twill with red piping; Woven thread-covered buttons; Embroidered heart appliqué at the interior.', 'lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero\'s De Finibus Bonorum et Malorum for use in a type specimen book.'),
(14, 'Praiano Brand Shirt', 2, 8, '350', 'uploads/product-size-2141-Islay-5.jpg', 'The world\'s oldest preserved garment, discovered by Flinders Petrie, is a \"highly sophisticated\" linen shirt from a First Dynasty Egyptian tomb at Tarkan, dated to c. 3000 BC: \"the shoulders and sleeves have been finely pleated to give form-fitting trimness while allowing the wearer room to move. The small fringe formed during weaving along one edge of the cloth has been placed by the designer to decorate the neck opening and side seam.\"', 'lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero\'s De Finibus Bonorum et Malorum for use in a type specimen book.'),
(15, 'White Shirt', 2, 2, '200', 'uploads/00354702_02_6.jpg', '# 100% Cotton\r\n# Imported\r\n# Button closure\r\nMachine Wash\r\n# PERFECT WEIGHT: Weighing in at 5.1 ounces, the Buck Camp Flannel Shirt is the perfect weight to be worn alone or layered, indoors or outside; you\'re gonna love this comfortable brushed cotton flannel shirt\r\n# DURABLE QUALITY: Our signature corduroy lined collar and cuffs not only look cool, but add stablility... which means they will hold their shape so you don\'t have to iron.  \r\n#TRADITIONAL STYLE: The classic single pocket design gives you a clean look while providing an option for storage; use the pencil slot to hold your pencil when scoring on the range, or for your sunglasses when not in use.', 'lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero\'s De Finibus Bonorum et Malorum for use in a type specimen book.'),
(16, 'T-shirt', 2, 2, '100', 'uploads/5842bc90232ac621fddb9ac7e41955a4.jpg', ' # 100% Cotton\r\n  # Imported\r\n # Button closure\r\n # Machine Wash\r\n # Regular fit through the chest for a relaxed, unrestricted fit with a printed neck label to maximize comfort\r\n # A classic cut and soft cotton fabric make this polo a go-to for the office or the weekend\r\n # Short-sleeve polo shirt in breathable, soft pique waffle knit', 'lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero\'s De Finibus Bonorum et Malorum for use in a type specimen book.'),
(17, 'Striking Blue Anarkali', 3, 6, '650', 'uploads/a034a1d9738d8bcfed47400c05d890f5.jpg', ' # Heavy Faux Georgette\r\n # STYLE :- This suit is Ready to wear. Just select your size & order. (3 pcs set)\r\n # Style :- Anarkali Suit || Work :- Chain Stitch Work + Stone || Top Fabric :- Heavy Faux Georgette || Bottom Fabric :- Santoon (2 Mtr) || Dupatta Fabric :- Heavy Faux Georgette (2.25 Mtr) ||\r\n # Gown Length (Top):- 54-55 inches.... if you want the length shorter, then please inform us within 24 hours after the order . If not Message received the maximum length will be kept as mentioned.\r\n # Size Chart Guide :- Refer Last Image For Size Measurement. Sizing Chart Shows Garment Dimensions. Size Chart Measurement :- If Your Chest Size Is 40 Inches Then Order Salwar Suit Label As ‘Large’ And You Will Get Salwar Suit With Chest 42 Inches Including 2 Inches Loosing With 4 Inches Extra Margin to Extend The Size For Better Look.\r\n# Color Variation Note :- Slight Variation In Actual Colour Vs Image Is Possible Due To Light Intensity During Photography & Monitor Colour Setting.', 'lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero\'s De Finibus Bonorum et Malorum for use in a type specimen book.'),
(18, 'Luxurious Embroidered Sherwani', 2, 7, '1000', 'uploads/cfe605c23347e06264fa08a60872df20.jpg', ' # Kurta Fabric :- Jacquard Silk || Pyjama Fabric :- Art Silk\r\n # Size Guide :- Sizing Chart Garment Dimensions, Not The Body Measurements. If Your Bare Chest Size Is 40 Inches Then Order Kurta Label As ‘M-40’ And \r\n # You Will Get Kurta With Chest 44 Inches Including 4 Inches Loosing For Better Look. Refer Last Image For Size Measurement.\r\n # Note :- Mojri, Shawl And Other Accessories Shown In Image Are For Reference Purpose Only. It Is Not Provided With Product. If You Need It, You Can Request It Which Costs Extra.\r\n # Color Variation Note :- Slight Variation In Actual Colour Vs Image Is Possible Due To Light Intensity During Photography & Monitor Colour Setting.', 'lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero\'s De Finibus Bonorum et Malorum for use in a type specimen book.'),
(19, 'Regal Patiala Sherwani', 2, 7, '1100', 'uploads/sherwani-1.jpg', 'Silk Blend\r\n# Imported \r\n# Button closure\r\n # Machine Wash\r\n # BEAUTIFUL KURTA PAJAMA AND WAISTCOAT SET : This is a 3-pieces set that includes jacket, kurta and a drawstring pajama. Traditional design on this kurta captures all of the details of the classic Indian men\'s garment with long sleeves, a long hemline with side vents and a mandarin collar. Waistcoat has beautiful floral print.\r\n #COMFORTABLE FIT: Sizing is designed for a regular relaxed fit. Available size chest S(38), M(40), L(42) and XL(44). Please see the size chart in description or image section before ordering.\r\n #HIGH QUALITY MATERIAL: Lightweight and breathable material gives this kurta pajama set soft, comfortable feel. Made from the finest silk blend fabric. \r\n# The kurta is lightweight with vented side. Designs feature modern and innovative details that appeal to everyone.', 'lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero\'s De Finibus Bonorum et Malorum for use in a type specimen book.'),
(20, 'Rajstani Sherwani', 2, 7, '1400', 'uploads/sherwani-2.jpg', ' # Dupion Art Silk\r\n # Imported\r\n # Button closure\r\n # Machine Wash\r\n # BEAUTIFUL, FULLY STITCHED 4-PIECES SET : This is a 4-pieces set that includes sherwani or overcoat, kurta, pajama and scarf. There is beautiful embroidery work around the collar and full embroidery on over coat or sherwani adds beauty to this set. Traditional design on this kurta captures all of the details of the classic Indian men\'s garment with long sleeves, a long hemline with side vents and a mandarin collar.\r\n # COMFORTABLE FIT: Sizing is designed for a regular relaxed fit. Available size chest S(38), M(40), L(42), XL(44). Please see the size chart in description or image section before ordering.\r\n # HIGH QUALITY MATERIAL: Lightweight and breathable material gives this kurta pajama set soft, comfortable feel. Made from the finest handloom polyester fabric. Finest embroidery textured work on all over the sherwani or overcoat. Designs feature modern and innovative details that appeal to everyone.', 'lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero\'s De Finibus Bonorum et Malorum for use in a type specimen book.'),
(21, 'Kate Spade Keds', 4, 3, '200', 'uploads/8cae03284c4479961af22559aa6cc4d8.jpg', '  # Canvas\r\n #  rubber-sole sole\r\n  # Vendor Name: Converse\r\n  # Style No: 7J794\r\n  # Material : Canvas\r\n  # Descr : CHUCK TAYLOR ALL STAR LOW\r\n  # Color : CHARCOAL', 'lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero\'s De Finibus Bonorum et Malorum for use in a type specimen book.'),
(22, 'Custom Van Shows', 4, 3, '300', 'uploads/f557257115cae26174d95c62c370f474.jpg', ' # 100% Fabric or Textile\r\n # Imported\r\n # Rubber sole\r\n # Shaft measures approximately high-top from arch\r\n # High-top sneaker with canvas upper and dinosaur graphic\r\n  # Iconic silhouette\r\n # Branded star ankle patch', 'lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero\'s De Finibus Bonorum et Malorum for use in a type specimen book.'),
(23, 'Adidas Strikes', 2, 6, '350', 'uploads/130103-0-adidas-SkateboardingMatchbreakSuper.jpg', '100% Polyester,\r\nImported,\r\nPolyester lining,\r\nzipper closure,\r\n14\" shoulder drop,\r\nGently wash by hand.\r\n Do not bleach. Line dry\r\nLifetime warranty.', ''),
(24, 'Nike Air MAX', 4, 7, '400', 'uploads/751f4d97c073029aae6689faa7c0301b.jpg', 'Is Discontinued By Manufacturer : No\r\nPackage Dimensions : 14 x 9.4 x 4.9 inches; 2.2 Pounds\r\nItem model number : CI3866\r\nDepartment : Mens\r\nDate First Available : February 15, 2020\r\nASIN : B07ZTV8MWH', 'lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero\'s De Finibus Bonorum et Malorum for use in a type specimen book.'),
(25, 'White Racer Nike', 4, 7, '300', 'uploads/137149-0-NikeSB-NyjahFree2T.jpg', 'Imported\r\nStyle#: 942888-001\r\nFlywire cables ensure secure midfoot lockdown.\r\nDual-fusion, soft foam midsole provides cushioning.\r\nGrooves on the outsole expand and flex with your foot.\r\nthe Free TR 8 trainer is designed to provide the stability and support you need. Full-bootie construction with a midfoot flywire cable system creates a firm, sock-like fit, while the updated, flatter heel provides a wider surface area to keep you steady on your feet', 'lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero\'s De Finibus Bonorum et Malorum for use in a type specimen book.'),
(26, 'Jack Shoe in London ', 4, 9, '650', 'uploads/images (1).jpg', 'Imported\r\nRubber sole\r\nHeel measures approximately 1.5 inches\"\r\nLeather and Rubber Sole\r\nImported\r\nShaft measures approximately 8\" from arch\r\nHeel measures approximately 1 1/2\"', 'lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero\'s De Finibus Bonorum et Malorum for use in a type specimen book.'),
(27, 'HUAWEI Watch Smartwatch', 5, 9, '1200', 'uploads/HUAWEI-Watch_300x350.jpg', 'Black Stainless Steel Case, Graphite Black Silicone Strap\r\n1.39 inch AMOLED colour screen, 454 x 454, PPI, The AMOLED touchscreen supports slide and touch gestures\r\n128 MB Storage, 16MB RAM\r\nConnectivity : Bluetooth: BT4.2, BLE / Wi-Fi: Not supported\r\nAndroid Wear, System Requirements : Android 4.4 or later or iOS 9.0 or later', 'lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero\'s De Finibus Bonorum et Malorum for use in a type specimen book.'),
(28, 'Tissot Pioneer', 5, 7, '400', 'uploads/Vintage-Tissot-square-gold-plated-watch-manual-winding-movement--300x350.jpg', '\r\nBrand	Tissot\r\nBand Material Type	Leather\r\nWatch Movement	Swiss Automatic\r\nDial Color	Silver\r\nBand Color	Black\r\nAbout this item\r\nCase Size: 39.30 mm, Band Width: 19 mm, Case Thickness: 9.75 mm\r\nSwiss automatic movement, 316L stainless steel case, Roman dial type, Date\r\nLeather bracelet, butterfly clasp closure\r\nWater-resistant up to a pressure of 3 bar (30 m / 100 ft): suitable for short periods of recreational swimming and showering, but no diving or snorkeling.', 'lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero\'s De Finibus Bonorum et Malorum for use in a type specimen book.'),
(29, 'Tissot T-Sharp', 5, 8, '250', 'uploads/tissot_k964_251-300x350.jpg', '\r\nBrand	Tissot\r\nBand Material Type	Leather\r\nWatch Movement	Swiss Automatic\r\nDial Color	Silver\r\nBand Color	Black\r\nAbout this item\r\nCase Size: 39.30 mm, Band Width: 19 mm, Case Thickness: 9.75 mm\r\nSwiss automatic movement, 316L stainless steel case, Roman dial type, Date\r\nLeather bracelet, butterfly clasp closure\r\nWater-resistant up to a pressure of 3 bar (30 m / 100 ft): suitable for short periods of recreational swimming and showering, but no diving or snorkeling.', 'lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero\'s De Finibus Bonorum et Malorum for use in a type specimen book.'),
(30, 'Titan N1502', 5, 6, '500', 'uploads/download.jpg', '\r\nBrand	Titan\r\nBand Material Type	Leather\r\nWatch Movement	Quartz\r\nDial Color	Blue\r\nBand Color	Blue\r\nAbout this item\r\nTRADITIONAL ELEGANCE: Men’s dress watch with a vintage nod; this stately timepiece transcends generations; it’s the perfect accessory for dress up or dress down\r\nPRECISION TIMEKEEPING: Smooth quartz movement and superior craftsmanship keeps accurate time all-day and all-night long\r\nSLIM ANALOG DISPLAY: Ultra slim 1.15mm thick case features a large round face with roman numbers that creates a classic and regal masterpiece\r\nDURABLE SCRATCH PROOF DISPLAY: High performance componentry and 37mm case clear mineral glass window provides scratch resistance to withstand everyday use\r\nSWEAT AND WATER RESISTANCE: Water resistant to 30m (100ft); withstands splashes or brief immersion in water, but not suitable for swimming or bathing.', 'lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero\'s De Finibus Bonorum et Malorum for use in a type specimen book.'),
(31, 'Crystal Folkner Watch.', 5, 6, '400', 'uploads/watch-4.jpg', '\r\nBrand	FIZILI\r\nDial Color	Blue\r\nBand Color	Black\r\nDisplay Type	Analog\r\nClasp Type	Tang Buckle', 'lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero\'s De Finibus Bonorum et Malorum for use in a type specimen book.'),
(32, 'Vintage Brooch', 7, 1, '1250', 'uploads/a661b88ba02440a3a74ba29af11ed1b0.jpg', 'THE PERFECT GIFT— Package comes with Nickel & Lead-Free Gold Plated Zinc alloy \" inch Gold Brooches and Pins in a high-class velvet Gift Pouch to store your jewelry.\r\nJONES NY— Inspired by the Boho-Chic Bohemian lifestyle fashion trend. First designed and conceptualized in NYC, then using a modern plating process to complete the silhouette. Great for city life, daily wearing, party celebration, family events, bohemian, prom night, birthday parties, or any occassion\r\nTHE STYLE— Our latest statement piece features elegant gold tonee finish floral design twisted petals with clear crystal rhinestones perfect fashion pins for bride-to-be during weddings, or other parties, prom night and casual events\r\nRISK FREE SHOPPING— We offer a 30-day satisfaction money back guarantee. Any problem with your purchase, message us for a quick replacement.\r\nRISK FREE SHOPPING— We offer a 30-day satisfaction money back guarantee. Any problem with your purchase, message us for a quick replacement.', 'lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero\'s De Finibus Bonorum et Malorum for use in a type specimen book.'),
(33, 'Paris Planet earings', 7, 1, '600', 'uploads/e84a0eaa5bae521bcf250c397b1bf173.jpg', '♥ Various Style - Every pair of earrings are unique and eye-catching. These earrings will be your ideal accessory, with their chic twist shape and beautiful shine, they will put the perfect finishing touch on a fashionable outfit.\r\n♥ Lightweight And Safe To Wear - These earrings and little charms are made of environmental friendly material, which will be safe to wear, light weight, and easy to wear and take off, shall be great collection of earrings. each pair of earrings is high color endurance, allergy free dangle drop earrings have an exquisite floral motif and are so classic and chic.\r\n[KEYWORDS]earrings for women hoop diamond gold stud earings fashion ear muffs winter silver christmas sigaga crystal pearl clip on studs cuffs dangle 14k women\'s small cuff earring sets hoops tragus crawler drop ringing jewelry day white rings black earrings for women hypoallergenic sensitive ears woman nickel free nickle rose wraps clip-on loop big dangling stainless steel dangly titanium dimond earing red butterfly boho long halloween feather warmer headband cheap earrings women\r\n[KEYWORDS]earrings for women bohemia tassel mardi gras chiefs mini mouse cute huggie tassle heart cat amber screw back silpada indian forest kate spade bamboo watermelon minimalist dangles turkey star beaded wicker pack wooden neon chain parrot bar large safety pin trendy channel moon earrings for women african leverback angel threader saftey bolt blue sapphire holiday chandelier cyan unique africa bohemian headbands plated 80s flat flower goth green acrylic trees earrings women\r\n[KEYWORDS]earrings for women thanksgiving snowman ethnic dainty turtle statement earcuffs clearance fairy ruby sunflower buds turquoise bow cubic zirconia purple funky climber running cartilage non piercing leopard bee earrings for women earrings for teen girls clip on earings teens hypoallergenic little ages 8-12 ear muffs girl sensitive ears earring holder gold toddler stud 10-12 christmas hoop 14k tree screw backs horse girls dangle baby trendy pearl back surgical earrings girls', 'lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero\'s De Finibus Bonorum et Malorum for use in a type specimen book.'),
(34, 'kelillas Design', 7, 4, '700', 'uploads/95374253-EC8F-43B8-8D06-1C4FC08725B8-scaled-300x350.jpeg', 'lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero\'s De Finibus Bonorum et Malorum for use in a type specimen book.', 'lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero\'s De Finibus Bonorum et Malorum for use in a type specimen book.'),
(35, 'Rings', 7, 4, '500', 'uploads/designer-gold-ladies-ring-861.jpg', ' # # Sterling silver band with milgrain edging and prong-set diamond accents   ###\r\nCrafted in .925 sterling silver  \r\n### All our diamond suppliers confirm that they comply with the Kimberley Process to ensure that their diamonds are conflict free\r\nImported', 'lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero\'s De Finibus Bonorum et Malorum for use in a type specimen book.'),
(36, 'Manish Malhotra Designed', 3, 2, '1500', 'uploads/saree-2.jpg', 'Saree Color: Beige | Blouse Color: Beige\r\nSaree Fabric:-Cotton Art Silk | Blouse Fabric :-Cotton Art Silk\r\nSaree Length :- *5.5 Meter* , Blouse Length :- *0.8 Meter*\r\nSaree Work :- Woven , Blouse Work :- Woven\r\nSaree Comes with Unstitched Blouse piece, which is attached with end of the saree only. Buyer have to cut blouse part from the saree. Stitching service will not be available. There might be color variation due to screen resolution and digital photography', 'In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content. Lorem ipsum may be used as a placeholder before final copy is available'),
(37, 'Kashmiri Salwar', 3, 0, '700', 'uploads/salwar-2.jpg', 'In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content. Lorem ipsum may be used as a placeholder before final copy is available', 'In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content. Lorem ipsum may be used as a placeholder before final copy is available'),
(38, 'Gucci Classy Gold', 8, 10, '1500', 'uploads/Gucci Classy Gold.jpg', 'Imported\r\nAuthentic New New 474575 9QIDT-1000 A MUST HAVE. Black, quilted shoulder bag, \'GG Marmont\'model from Gucci. Made of velvet. Fastened with a metal snap. Decorated with a logo. Detachable shoulder chain. Inside three compartments, a pocket fastened with a zip, two inset pockets and sixteen card slots.\r\nMetal elements in a golden tone. Comes in a box. 8\'\' x 5.5\'\' x 2 \'\' chain 24\' Height: 13cm Width: 20cm LIMITED NUMBERS MADE WORLDWIDE\r\nComes in Box. Tags. Made in Italy', 'In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content. Lorem ipsum may be used as a placeholder before final copy is available'),
(39, 'GG Small Velvet', 9, 10, '530', 'uploads/GG Small  Velvet.jpg', ' #   Imported\r\n  #  Authentic New New 474575 9QIDT-1000 A MUST HAVE. Black, quilted shoulder bag, ##  \'GG Marmont\'model from Gucci.  ## Made of velvet. Fastened with a metal snap.  ## Decorated with a logo. ##  Detachable shoulder chain. # #  Inside three compartments, a pocket fastened with a zip, two inset pockets and sixteen card slots.\r\n ### Metal elements in a golden tone. Comes in a box. 8\'\' x 5.5\'\' x 2 \'\' chain 24\'  #  # Height: 13cm   ## Width: 20cm    @@ LIMITED NUMBERS MADE WORLDWIDE\r\nComes in Box. Tags. # # Made in Italy', 'In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content. Lorem ipsum may be used as a placeholder before final copy is available'),
(40, 'Gucci Backpack', 9, 10, '1200', 'uploads/Backpaxk.jpg', '# 100% Leather #   \r\nGUCCI     #    \r\nLEATHER       # \r\n #  BACKPACK GUCCI,  # LEATHER 100%,  #  color RED,      # Measurements 20x28x14cm, Handle 7cm, CO,   # product code 5361920KL0T1000\r\n     ##           FOR CLOTHING: Brand size refers to the official size of the brand.  ######### This will be the size you will find on the product\'s label or box. || FOR SHOES: we show the UK (United Kingdom) size. In the case of brands that use different sizes scales, we will convert so that you have the corresponding size corresponding.', 'In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content. Lorem ipsum may be used as a placeholder before final copy is available'),
(41, 'DYI Jellyfio Custom', 8, 1, '760', 'uploads/758afe570800c47fab57729a6e2bde4a.jpg', '\r\nItem Type	Wallet\r\nGender	Women\r\nMain Material	Polyester\r\nbags method of opening bag	zipper\r\nwallet design	key wallet\r\nbags texture	other texture\r\nbags pattern	solid color none pattern\r\nsmall bag inner structure	others\r\nbags fashion element	leuconostoc\r\nbags shape	horizontal\r\nhardness	soft\r\nbags	cartoon cute', 'In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content. Lorem ipsum may be used as a placeholder before final copy is available'),
(42, 'Global Vision Sunglass', 6, 9, '300', 'uploads/2269_eye-glasses-contact-lenses-market-research-report.jpeg', 'Plastic frame\r\nPlastic lens\r\nNon-Polarized\r\nUV Protection Coating coating\r\nLens width: 2.36 inches\r\n#\r\nUV400 PROTECTION - Sunglasses provide UV 400 protection.  #  Lenses can block 100% of both UVA radiation.Anti scratch, durable and easy to clean. At the same time, High-definition lens allows you to better observe the scenery in the sun, ensure clear vision and more natural vision sight.\r\n#\r\nHIGH QUALITY – Made of high quality material that is durable enough for long time using. #  They are suitable for any climate and weather conditions.', 'In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content. Lorem ipsum may be used as a placeholder before final copy is available'),
(43, 'Pine Sota Glass', 6, 3, '400', 'uploads/PASHA_PINE_PATA_300.jpg', ' #  Plastic frame\r\n  #  composite lens  #   non-polarized\r\n  # Lens width: 54 millimeters # \r\nLens height: 41.3 millimeters  # \r\nBridge: 17 millimeters     #  \r\nArm: 135 millimeters', 'In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content. Lorem ipsum may be used as a placeholder before final copy is available'),
(44, 'Tommy Hilfiger egyWacth', 2, 11, '200', 'uploads/tommy.jpg', '  # Reference Number: 1791557   # \r\n  #Dial Color: Red   \r\n # Series: Denim\r\n  # Glass: Mineral\r\n   # Brand: Tommy Hilfiger\r\n\r\nWater Resistance: 30\r\nMovement: Quartz\r\nCase Diameter: 40 mm\r\nGender: Men\r\nMade in: China', ''),
(45, 'Tommy hilfiger Hoodie', 2, 11, '200', 'uploads/hoodie.jpg', 'Tommy Hilfiger men\'s hoodie. Everything you love about our ridiculously soft hoodies with our archival logo. Part of our Tommy Jeans collection.\r\nRegular Fit.\r\n50% cotton, 50% polyester.\r\nImported.\r\nStyle #:  DM11016', ''),
(46, 'Tommy Sweat Shirt', 2, 11, '150', 'uploads/sweat shirt (1).jpg', 'Tommy Hilfiger men\'s sweatshirt. Cut in a roomy fit, our sporty signature sweatshirt is designed from a cotton and polyester weave for softness and strength. A limited-edition style from our TH Signature Capsule.\r\n\r\n# Relaxed Fit.\r\n# 72% cotton, 28% polyester.\r\n# Zip closure at neck, chest pocket.\r\n# Imported.\r\nStyle #:  MW17891', ''),
(47, 'Tommy hilfiger Polo Shirt', 2, 11, '150', 'uploads/tommy-hilfiger-polo-shirt-300x350.jpeg', ' # 100% Cotton\r\n # Imported\r\n #Magnetic closure\r\n # Machine Wash \r\n # Designed with and for people with disabilities.  \r\n# Tommy Hilfiger Adaptive men’s polo. What we do best—our iconic polo, classically cut for a comfortable fit in pure cotton. Hidden beneath a \r\n traditional polo placket, our innovative magnetic closures make getting dressed a breeze. #  Part of our Adaptive Collection, designed for ease of dressing in classic Tommy style.\r\n # Functional top button, magnetic front closure designed to appear as traditional button and polo front. Regular fit (Sleeves that fall just above the elbow, relaxed fit).\r\n # Close all fasteners prior to wash. #  Machine wash warm. Tumble dry gentle cycle. # Do not iron magnets. #  Additional care instructions may be found on the garment.', '');

-- --------------------------------------------------------

--
-- Table structure for table `rents`
--

CREATE TABLE `rents` (
  `id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `totalprice` varchar(255) NOT NULL,
  `orderstatus` varchar(255) NOT NULL,
  `paymentmode` varchar(255) NOT NULL,
  `timestamp` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `rents`
--

INSERT INTO `rents` (`id`, `uid`, `totalprice`, `orderstatus`, `paymentmode`, `timestamp`) VALUES
(1, 1, '250', 'Order Placed', 'on', '0000-00-00 00:00:00'),
(2, 4, '500', 'Order Placed', 'cod', '0000-00-00 00:00:00'),
(3, 4, '400', 'Order Placed', 'cod', '0000-00-00 00:00:00'),
(4, 1, '423', 'Order Placed', 'cod', '0000-00-00 00:00:00'),
(5, 4, '3430', 'Dispatched', 'on', '0000-00-00 00:00:00'),
(6, 1, '500', 'Order Placed', 'on', '0000-00-00 00:00:00'),
(7, 2, '1400', 'Order Placed', 'on', '0000-00-00 00:00:00'),
(8, 2, '1600', 'Delivered', 'cod', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `store`
--

CREATE TABLE `store` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `store`
--

INSERT INTO `store` (`id`, `name`) VALUES
(1, 'Nobanno Boutiques'),
(2, 'Nogor Polli'),
(3, 'Rich Man'),
(4, 'Anjan\'s'),
(5, 'Ecstasy'),
(6, 'Yellow'),
(7, 'Freeland'),
(8, 'Dorjibari'),
(9, 'Kay Kraft'),
(10, 'GUCCI Bangladesh'),
(11, 'Tommy Hilfiger BD');

-- --------------------------------------------------------

--
-- Table structure for table `userinfo`
--

CREATE TABLE `userinfo` (
  `id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `company` varchar(255) NOT NULL,
  `address1` varchar(255) NOT NULL,
  `address2` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `zip` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `userinfo`
--

INSERT INTO `userinfo` (`id`, `uid`, `firstname`, `lastname`, `company`, `address1`, `address2`, `city`, `state`, `country`, `zip`, `mobile`) VALUES
(1, 1, 'abalu', 'day', 'techo naldao', 'kiya sin ponfg', '', 'jechsa', 'leonm', 'AF', '3121', '97532467890'),
(2, 4, 'Robert Huffman', 'Sarah Klein', 'Vaughn Nixon Co', '35 Nobel Parkway', 'Similique in adipisc', 'Sed nulla recusandae', 'Optio fugiat ut de', '', '12262', '+1181881-2318'),
(3, 2, 'Melissa Phelps', 'Brynne Oneil', 'Lowe Dillard Trading', '43 White Cowley Road', 'Cupiditate qui minus', 'Irure possimus magn', 'Quis quis qui sed sa', 'DZ', '48113', '+1198415-7333');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `timestamp` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `timestamp`) VALUES
(1, 'user@gmail.com', '$2y$10$3QDzAyqXLH3MXDIbGuxre.32mScTRbPmltJiy1RJvrjYj3ruycHO6', '0000-00-00 00:00:00'),
(2, 'user2@gmail.com', '$2y$10$KSU6Af0Z9ATmbejk4hlT5uCebf1FXmpUj5UEsXgO1sivNTeYhdwv6', '0000-00-00 00:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orderitems`
--
ALTER TABLE `orderitems`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ordertracking`
--
ALTER TABLE `ordertracking`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rents`
--
ALTER TABLE `rents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `store`
--
ALTER TABLE `store`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userinfo`
--
ALTER TABLE `userinfo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `orderitems`
--
ALTER TABLE `orderitems`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `ordertracking`
--
ALTER TABLE `ordertracking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `rents`
--
ALTER TABLE `rents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `store`
--
ALTER TABLE `store`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `userinfo`
--
ALTER TABLE `userinfo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
