<?php 
session_start();
require_once ('../database/config.php');
if(!isset($_SESSION['email']) & empty($_SESSION['email'])){
	header('location: login.php');
}

if (isset($_POST) & !empty($_POST)){
    $name=mysqli_real_escape_string($connection, $_POST['storename']);
    $sql="INSERT INTO store (name) VALUES ('$name')";
    $res=mysqli_query($connection, $sql);
    if($res){
        $smsg="Store Added";
        //header('location:stores.php');
    }else{
        $fmsg="Failed to add new store!";
    }
}
?>
<?php //include('inc/header.php')?>
<?php include('inc/nav.php')?>

<div class="card">
  <div class="card-body">
  <h5 class="text-center text-dark">ADD a New Store!</h5>
  </div>
</div>

<section id="content">
	<div class="content-blog">
	   <div class="container">
	<?php if(isset($fmsg)){ ?> <div class="alert alert-danger" role="alert"> <?php echo $fmsg;?> </div> <?php } ?>
	<?php if(isset($smsg)){ ?> <div class="alert alert-success" role="alert"> <?php echo $smsg;?> </div> <?php } ?>
	      <form method="post">
		    <div class="form-group">
			 <label for="Storename">Store Name</label>
			 <input type="text" class="form-control" name="storename" id="storename" placeholder="Store Name">
			</div>
			<button type="submit" class="btn btn-dark">Submit</button>

		  </form>

	   </div>
	</div>

	</section>

<?php include('inc/footer.php')?>    